/**
 * 
 */
/**
 * @author fesantiago
 *
 */
module ChallengeSprint2 {
	requires java.desktop;
}