package br.com.principal.teste;

import javax.swing.JOptionPane;

import br.com.campobusca.beans.CampoBusca;
import br.com.chatbot.beans.ChatBot;
import br.com.documentacao.beans.Documentacao;
import br.com.documentacao.beans.documentoDois;
import br.com.documentacao.beans.documentoQuatro;
import br.com.documentacao.beans.documentoTres;
import br.com.documentacao.beans.documentoUm;
import br.com.infocvm.beans.infoCVM;
import br.com.noticias.beans.Noticias;
import br.com.simulador.beans.Empresa;
import br.com.simulador.beans.Simulador;

public class ProgramaPrincipal {

	public static void main(String[] args) {
		
		CampoBusca busca = new CampoBusca("Pesquisa");
		ChatBot b3tinho = new ChatBot("Perguntas frequentes" , "Redireciona");
		documentoUm documento1 = new documentoUm("CNPJ");
		documentoDois documento2 = new documentoDois("Razão Social");
		documentoTres documento3 = new documentoTres("Faturamento");
		documentoQuatro documento4 = new documentoQuatro("Quantidade funcionarios");
		Empresa b3 = new Empresa("NuBank" , "Financeiro", 2015);
		Simulador simulador = new Simulador(30, 10000000.00);
		Noticias noticias = new Noticias("22012023", "UOL", "Financeiro");
		infoCVM cvm = new infoCVM("Crescimento", "2010");
		Documentacao documentacao = new Documentacao("Abertura", "Agro");
		
		System.out.println(busca.campoBusca + "\n" + b3tinho.faqs + "\n" + b3tinho.redirecionar +  "\n" + documento1.tituloUm + "\n" + documento2.tituloDois + "\n" + documento3.tituloTres
							+ "\n" + documento4.tituloQuatro + "\n" + b3.anoAbertura + "\n" +  b3.nome + "\n" + b3.setor + "\n" + simulador.tempo +"\n" +  simulador.valor + "\n" + noticias.data + "\n" + noticias.fonte + "\n" + 
							noticias.setor + "\n" + cvm.data + "\n" + cvm.tipo + "\n" + documentacao.nome +  "\n" + documentacao.tipo);
		
		
		
	}

}
