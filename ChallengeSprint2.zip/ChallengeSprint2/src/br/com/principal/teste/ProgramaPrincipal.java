package br.com.principal.teste;

import br.com.campobusca.beans.CampoBusca;
import br.com.chatbot.beans.ChatBot;
import br.com.documentacao.beans.Documentacao;
import br.com.documentacao.beans.documentoDois;
import br.com.documentacao.beans.documentoQuatro;
import br.com.documentacao.beans.documentoTres;
import br.com.documentacao.beans.documentoUm;
import br.com.infocvm.beans.infoCVM;
import br.com.noticias.beans.Noticias;
import br.com.simulador.beans.Empresa;
import br.com.simulador.beans.Simulador;

public class ProgramaPrincipal {

	public static void main(String[] args) {
		
		CampoBusca busca = new CampoBusca("Pesquisa");
		ChatBot b3tinho = new ChatBot();
		documentoUm documento1 = new documentoUm();
		documentoDois documento2 = new documentoDois();
		documentoTres documento3 = new documentoTres();
		documentoQuatro documento4 = new documentoQuatro();
		Empresa b3 = new Empresa();
		Simulador simulador = new Simulador();
		Noticias noticias = new Noticias();
		infoCVM cvm = new infoCVM();
		Documentacao documentacao = new Documentacao();
		
		/* Doceria doceriaDois = new Doceria();
		 * 
		 * doceriaDois.setNome_doce(JOptionPane.showInputDialog("Digite o nome do doce"
		 * + doceriaDois.getNome_doce()));
		 * doceriaDois.setValor(Double.parseDouble(JOptionPane.
		 * showInputDialog("Digite o valor" + doceriaDois.getValor())));
		 * doceriaDois.setDestinatario(JOptionPane.
		 * showInputDialog("Digite o nome do destinatario" +
		 * doceriaDois.getDestinatario()));
		 * doceriaDois.setValidade(Integer.parseInt(JOptionPane.
		 * showInputDialog("Digite a validade" + doceriaDois.getValidade())));
		 * 
		 * System.out.println("\n" + "O nome do doce é: " + doceriaDois.getNome_doce() +
		 * "\n" + "O valor é: " + doceriaDois.getValor() + "\n" + "A validade é: " +
		 * doceriaDois.getValidade() + "\n" + "O destinatario é: " +
		 * doceriaDois.getDestinatario()); */
	}

}
