package br.com.infocvm.beans;

public class infoCVM {
	
	public String tipo;
	public String data;
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	

	public infoCVM(String recebeTipo, String recebeData) {
		setTipo(recebeTipo);
		setData(recebeData);
		
	}
	
	public infoCVM() {}
}
