package br.com.chatbot.beans;

public class ChatBot {
	
	public String faqs;
	public String redirecionar;
	
	public String getFaqs() {
		return faqs;
	}
	public void setFaqs(String faqs) {
		this.faqs = faqs;
	}
	public String getRedirecionar() {
		return redirecionar;
	}
	public void setRedirecionar(String redirecionar) {
		this.redirecionar = redirecionar;
	}
	
	public ChatBot(String recebeFaqs, String recebeRedirecionar) {
		setFaqs(recebeFaqs);
		setRedirecionar(recebeRedirecionar);
	}
	
	public ChatBot() {}

}
