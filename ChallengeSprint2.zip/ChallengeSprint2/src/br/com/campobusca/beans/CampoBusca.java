package br.com.campobusca.beans;

public class CampoBusca {

	public String campoBusca;

	public String getCampoBusca() {
		return campoBusca;
	}

	public void setCampoBusca(String campoBusca) {
		this.campoBusca = campoBusca;
	}
	
	public CampoBusca(String recebeCampoBusca) {
		setCampoBusca(recebeCampoBusca);
	}
	
	public CampoBusca() {}
	
}
