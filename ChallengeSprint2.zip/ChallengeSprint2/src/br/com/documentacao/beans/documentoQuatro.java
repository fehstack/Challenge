package br.com.documentacao.beans;

public class documentoQuatro {
	
	public String tituloQuatro;

	public String getTituloQuatro() {
		return tituloQuatro;
	}

	public void setTituloQuatro(String tituloQuatro) {
		this.tituloQuatro = tituloQuatro;
	}

	
	public documentoQuatro(String recebeTituloQuatro) {
		setTituloQuatro(recebeTituloQuatro);
		
	}
	
	public documentoQuatro() {}
	
}
