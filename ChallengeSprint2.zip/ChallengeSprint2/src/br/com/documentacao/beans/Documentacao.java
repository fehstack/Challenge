package br.com.documentacao.beans;

public class Documentacao {
	
	public String nome;
	public String tipo;
	
	

	public String getNome() {
		return nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}



	public String getTipo() {
		return tipo;
	}



	public void setTipo(String tipo) {
		this.tipo = tipo;
	}



	public Documentacao(String recebeNome, String recebeTipo) {
		setNome(recebeNome);
		setTipo(recebeTipo);
		
	}
	
	public Documentacao() {}

}
