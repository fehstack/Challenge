package br.com.documentacao.beans;

public class documentoDois {
	
	public String tituloDois;

	public String getTituloDois() {
		return tituloDois;
	}

	public void setTituloDois(String tituloDois) {
		this.tituloDois = tituloDois;
	}
	
	public documentoDois(String recebeTituloDois) {
		setTituloDois(recebeTituloDois);
	}

	
	public documentoDois() {}
}
