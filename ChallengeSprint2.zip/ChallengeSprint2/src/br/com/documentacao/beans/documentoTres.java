package br.com.documentacao.beans;

public class documentoTres {

	public String tituloTres;

	public String getTituloTres() {
		return tituloTres;
	}

	public void setTituloTres(String tituloTres) {
		this.tituloTres = tituloTres;
	}
	
	public documentoTres(String recebeTituloTres) {
		setTituloTres(recebeTituloTres);
	}
	
	public documentoTres() {}
	
	
}
