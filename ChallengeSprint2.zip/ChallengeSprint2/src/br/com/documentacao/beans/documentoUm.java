package br.com.documentacao.beans;

public class documentoUm {
	
	public String tituloUm;

	public String getTituloUm() {
		return tituloUm;
	}

	public void setTituloUm(String tituloUm) {
		this.tituloUm = tituloUm;
	}

	
	public documentoUm(String recebeTituloUm) {
		setTituloUm(recebeTituloUm);
	}
	
	public documentoUm() {}
}
