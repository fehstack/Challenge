package br.com.noticias.beans;

public class Noticias {
	
	public String data;
	public String fonte;
	public String setor;
	
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getFonte() {
		return fonte;
	}
	public void setFonte(String fonte) {
		this.fonte = fonte;
	}
	public String getSetor() {
		return setor;
	}
	public void setSetor(String setor) {
		this.setor = setor;
	}
	
	public Noticias(String recebeData, String recebeFonte, String recebeSetor) {
		setData(recebeData);
		setFonte(recebeFonte);
		setSetor(recebeSetor);
	}
	
	public Noticias() {}

}
