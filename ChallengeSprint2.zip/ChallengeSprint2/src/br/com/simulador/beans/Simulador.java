package br.com.simulador.beans;

public class Simulador {
	
	public int tempo;
	public double valor;
	public int getTempo() {
		return tempo;
	}
	public void setTempo(int tempo) {
		this.tempo = tempo;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public Simulador(int recebeTempo, double recebeValor) {
		setTempo(recebeTempo);
		setValor(recebeValor);
	}
	
	public Simulador() {}

}
