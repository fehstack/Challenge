package br.com.simulador.beans;

public class Empresa {
	
	public String nome;
	public String setor;
	public int anoAbertura;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSetor() {
		return setor;
	}
	public void setSetor(String setor) {
		this.setor = setor;
	}
	public int getAnoAbertura() {
		return anoAbertura;
	}
	public void setAnoAbertura(int anoAbertura) {
		this.anoAbertura = anoAbertura;
	}
	
	public Empresa(String recebeNome, String recebeSetor, int recebeAnoAbertura) {
		setNome(recebeNome);
		setSetor(recebeSetor);
		setAnoAbertura(recebeAnoAbertura);
		
	}

	
	public Empresa() {}
	

}
